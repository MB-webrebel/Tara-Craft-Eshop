<?php
interface IProduct
{
	public function calculatePrice();
}