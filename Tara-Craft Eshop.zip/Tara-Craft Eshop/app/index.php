<?php
	$urlPrefix = "./";
	require_once $urlPrefix . 'Services/AppService.php';
?>

<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title>Titulok</title>
    <link rel="stylesheet" type="text/css" href="myStyles.css">
  </head>

  <body>
    <div>
		
	</div>
  </body>
</html>
