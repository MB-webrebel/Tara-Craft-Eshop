<?php
	if(!isset($safeFile)){
		die('Problem with loading file!');
	}
?>

<footer class="text-muted ">
  <div class="container ">
	<p class="float-right">
	  <a href="#"><i class="fas fa-arrow-up"></i> Hore</a>
	</p>
	<p>Vyrobil Q.point - MB. Všetky práva vyhradené!</p>
	<p>© 2021 Store. All rights reserved | Design by <a href="http://w3layouts.com/">W3layouts</a></p>
  </div>
</footer>