<?php
	if(!isset($safeFile)){
		die('Problem with loading file!');
	}
?>

<!-- RIGHT / ORDER COMPLETED -->
<div id="checkout" class="col-md-9 bg-white p-5">

	<div class="container">
		<div>
			<h2>Ďakujeme za nákup</h2>
			<p class="lead">Vaša objednávka bola odoslaná. Budeme Vás kontaktovať ohľadom vybavenia objednávky v čo najkratšom čase. V prípade otázok nám zavolajte alebo nám napíšte email ;).</p>
		</div>							
	</div>

</div>