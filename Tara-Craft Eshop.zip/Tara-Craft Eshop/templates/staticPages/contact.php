<?php
	if(!isset($safeFile)){
		die('Problem with loading file!');
	}
?>

<!-- RIGHT / CONTACT -->
<div id="checkout" class="col-md-9 bg-white p-5">

	<div class="container">
		<div>
			<h2 style="text-align:left">Kontakt</h2>
			<p>Email: infotaracraft@gmail.com</p>
			<p>Tel.číslo: +421 201 123 456</p>
		</div>							
	</div>

</div>