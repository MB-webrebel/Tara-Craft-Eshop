<?php
	if(!isset($safeFile)){
		die('Problem with loading file!');
	}
?>

<!-- RIGHT / ABOUT US -->
<div id="checkout" class="col-md-9 bg-white p-5">

	<div class="container">
		<div>
			<h2>O nás</h2>
			<p></p>
		</div>							
	</div>

</div>